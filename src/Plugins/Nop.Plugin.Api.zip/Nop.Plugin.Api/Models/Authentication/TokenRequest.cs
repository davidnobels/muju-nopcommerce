﻿namespace Nop.Plugin.Api.Models.Authentication
{
    public class TokenRequest
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}
