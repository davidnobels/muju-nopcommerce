﻿namespace Nop.Plugin.Api.DTO.Customers
{
    public class OrderCustomerDto : BaseCustomerDto
    {
    }
}
