﻿using Newtonsoft.Json;

namespace Nop.Plugin.Api.DTO.Products
{
    public class ProductsCountRootObject
    {
        [JsonProperty("count")]
        public int Count { get; set; }
    }
}
