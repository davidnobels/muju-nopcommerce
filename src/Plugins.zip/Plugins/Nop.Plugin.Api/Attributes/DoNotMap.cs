﻿using System;

namespace Nop.Plugin.Api.Attributes
{
    public class DoNotMapAttribute : Attribute
    {
        // just a marker
    }
}
