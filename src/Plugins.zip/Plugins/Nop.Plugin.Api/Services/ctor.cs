﻿namespace Nop.Plugin.Api.Services
{
    internal class ctor
    {
    }
}