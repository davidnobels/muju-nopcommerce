﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Tax.FixedOrByCountryStateZip.Models
{
    public partial class FixedTaxRateListModel : BasePagedListModel<FixedTaxRateModel>
    {
    }
}