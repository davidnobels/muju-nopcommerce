﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Pickup.PickupInStore.Models
{
    public class StorePickupPointSearchModel: BaseSearchModel
    {
    }
}
