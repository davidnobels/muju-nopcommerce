﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.SendinBlue.Models
{
    /// <summary>
    /// Represents message template search model
    /// </summary>
    public partial class SendinBlueMessageTemplateSearchModel : BaseSearchModel
    {
    }
}